<nav class="top-nav">
   <ul>
      <li>
         <a href="<?php echo URLROOT; ?>/index">Heim</a>
      </li>
      <li>
         <a href="<?php echo URLROOT; ?>/parts">Teile</a>
      </li>
      <li>
         <a href="<?php echo URLROOT; ?>/fahrzeuge">Fahrzeuge</a>
      </li>
      <li>
         <a href="<?php echo URLROOT; ?>/ankauf">Ankauf</a>
      </li>
      <li>
         <a href="<?php echo URLROOT; ?>/pages/about">Kontakt Uns</a>
      </li>
      <li class="btn-login">
         <?php if (isset($_SESSION['user_id'])) : ?>
            <a href="<?php echo URLROOT; ?>/users/logout">Log out</a>
         <?php else : ?>
            <a href="<?php echo URLROOT; ?>/users/login">Login</a>
         <?php endif; ?>
      </li>
   </ul>
</nav>