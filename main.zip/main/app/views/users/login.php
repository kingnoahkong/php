<?php
require APPROOT . '/views/includes/head.php';
?>
<div class="navbar">
   <?=
   require APPROOT . '/views/includes/navigation.php';
   ?>
   <h2>Ali Trucks & Teile</h2>
</div>

<div class="container-login">
   <div class="wrapper-login">
      <h2>Einloggen</h2>
      <form action="<?= URLROOT; ?>/users/login" method="POST">

         <input type="text" name="username" placeholder="Email *">
         <span class="invlaidFeedback">
            <?= $data['usernameError']; ?>
         </span>

         <input type="password" name="password" placeholder="Kennwort *">
         <span class="invlaidFeedback">
            <?= $data['passwordError']; ?>
         </span>

         <button id="submit" type="submit" value="submit">Einloggin</button>

         <p class="options">Keine Konto? <a href="<?= URLROOT ?>/users/register">Neu Konto erstellen</a></p>
      </form>
   </div>
</div>
<?php
?>