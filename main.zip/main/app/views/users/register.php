<?php
require APPROOT . '/views/includes/head.php';
?>
<div class="navbar">
   <?= 
   require APPROOT . '/views/includes/navigation.php'; 
   ?> 
   <h2>Ali Trucks & Teile</h2>
</div>

<div class="container-login">
   <div class="wrapper-login">
      <h2>Kontnto Erstellen</h2>
      <form action="<?= URLROOT; ?>/users/login" method="POST">

         <input type="text" name="title" placeholder="Title *">
         <span class="invlaidFeedback">
            <?= $data['titleError']; ?>
         </span>

         <input type="text" name="name" placeholder="Name *">
         <span class="invlaidFeedback">
            <?= $data['nameError']; ?>
         </span>

         <input type="text" name="tel" placeholder="Fone Nr *">
         <span class="invlaidFeedback">
            <?= $data['telError']; ?>
         </span>

         <input type="email" name="email" placeholder="Email *">
         <span class="invlaidFeedback">
            <?= $data['emailError']; ?>
         </span>

         <input type="password" name="password" placeholder="Kennwort *" name="password">
         <span class="invlaidFeedback">
            <?= $data['passwordError']; ?>
         </span>

         <input type="password" name="password" placeholder=" Kennwort bestätigen *" name="confirmPassword">
         <span class="invlaidFeedback">
            <?= $data['confirmPasswordError']; ?>
         </span>

         <button id="submit" type="submit" value="submit">Kontro Erstellen</button>

      </form>
   </div>
</div>
<?php
?>