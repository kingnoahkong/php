<?php
require APPROOT . '/views/includes/head.php';
?>
<div id="section-landing">
   <?php
   require APPROOT . '/views/includes/navigation.php';
   ?>

   <div class="wrapper-landing">
      <h1>Ali Trucks & Parts</h1>
      <h2>For all your trucking needs</h2>
   </div>
</div>
