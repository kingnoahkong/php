<?php
// DB Parameters
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'atp');

//Approot
define('APPROOT', dirname(dirname(__FILE__)));

//URL root (dynamic links)
define('URLROOT', 'localhost/home/main');

//site name
define('SITENAME', 'MVC Framework');