<?php
class Users extends Controller {
   public function __construct(){
      $this->userModel = $this->model('User');
   }
   
   public function register(){
      $data = [
         'title' => '',
         'name' => '',
         'tel' => '',
         'email' => '',
         'password' => '',
         'confirmPassword' => '',
         'titleError' => '',
         'nameError' => '',
         'telError' => '',
         'emailError' => '',
         'passwordError' => '',
         'confirmPasswordError' => '',
      ];

      if($_SERVER['REQUEST_METHOD'] == 'POST'){
         //sanitize post data
         $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

         $data = [
            'title' => trim($_POST['title']),
            'name' => trim($_POST['name']),
            'tel' => trim($_POST['tel']),
            'email' => trim($_POST['email']),
            'password' => trim($_POST['password']),
            'confirmPassword' => trim($_POST['confirmPassword']),
            'titleError' => '',
            'nameError' => '',
            'telError' => '',
            'emailError' => '',
            'passwordError' => '',
            'confirmPasswordError' => '',
         ];

         $validationA = "/^[a-ZA-Z]*$";
         $telValidation = "/^[0-9\.\-\s]*$";
         $passwordValidation = "/^(.{0,7}|[^a-z]*|[^\d]*)$/i";

         if(empty($data['title'])){
            $data['titleError'] = 'Bitte geben Sie ein Title';
         } elseif (!preg_match($validationA, $data['title'])){
            $data['titleError'] = 'Geben Sie ein gultiges Title!';
         }

         if (empty($data['name'])) {
            $data['nameError'] = 'Name kann nicht leer sein!';
         } elseif (!preg_match($validationA, $data['name'])) {
            $data['nameError'] = 'Die gegebne name ist nicht gultig';
         }

         if (empty($data['tel'])) {
            $data['telError'] = 'Fone Nr ist notig';
         } elseif (!preg_match($telValidation, $data['tel'])) {
            $data['telError'] = 'Die gegebne Fone Nr ist nicht gultig';
         }

         if (empty($data['email'])) {
            $data['emailError'] = 'Email kann nicht leer sein.';
         } elseif (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            $data['emailError'] = 'Email ist nicht gultig.';
         } else {
            //Check if email exists.
            if ($this->userModel->findUserByEmail($data['email'])) {
               $data['emailError'] = 'Email ist bereit regertiert.';
            }
         }

         if (empty($data['password'])) {
            $data['passwordError'] = 'Bitte geben ein Kennwort ein.';
         } elseif (strlen($data['password']) < 8) {
            $data['passwordError'] = 'Kennwort muss 8+ Charcter lang!';
         } elseif (preg_match($passwordValidation, $data['password'])) {
            $data['passwordError'] = 'Kennwort muss ein Nummer enthalten.';
         }

         if (empty($data['confirmPassword'])) {
            $data['confirmPasswordError'] = 'Geben Sie Ihr Kennwort wieder ein.';
         } else {
            if ($data['password'] != $data['confirmPassword']) {
               $data['confirmPasswordError'] = 'Die Kennwörter sind nicht identisch.';
            }
         }

         if (empty($data['usernameError']) && empty($data['emailError']) && empty($data['passwordError']) && empty($data['confirmPasswordError'])) {

            // Hash password
            $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);

            //Register user from model function
            if ($this->userModel->register($data)) {
               //Redirect to the login page
               header('location: ' . URLROOT . '/users/login');
            } else {
               die('Das Konto könnte nicht erstellet werden, bitte versuchen Sie nochmal.');
            }
         }

      }
      $this->view('users/register', $data);
   }

   public function login(){
      $data = [
         'title' => 'Login page',
         'usernameError' => '',
         'passwordError' => ''
      ];

      $this->view('users/login', $data);
   }
}