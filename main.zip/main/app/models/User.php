<?php

class User {
   private $db;
   public function __construct()
   {
      $this->db = new Database;
   }

   public function register($data)
   {
      $this->db->query('INSERT INTO customers (title, cname, tel, email, password) VALUES(:title, :cname, :tel, :email, :password)');

      //Bind values
      $this->db->bind(':title', $data['title']);
      $this->db->bind(':cname', $data['name']);
      $this->db->bind(':tel', $data['tel']);
      $this->db->bind(':email', $data['email']);
      $this->db->bind(':password', $data['password']);

      //Execute function
      if ($this->db->execute()) {
         return true;
      } else {
         return false;
      }
   }

   public function login($username, $password)
   {
      $this->db->query('SELECT * FROM customers WHERE username = :email');

      //Bind value
      $this->db->bind(':email', $username);

      $row = $this->db->single();

      $hashedPassword = $row->password;

      if (password_verify($password, $hashedPassword)) {
         return $row;
      } else {
         return false;
      }
   }

   //Find user by email. Email is passed in by the Controller.
   public function findUserByEmail($email)
   {
      //Prepared statement
      $this->db->query('SELECT * FROM users WHERE email = :email');

      //Email param will be binded with the email variable
      $this->db->bind(':email', $email);

      //Check if email is already registered
      if ($this->db->rowCount() > 0) {
         return true;
      } else {
         return false;
      }
   }

   public function getUsers()
   {
      $this->db->query("SELECT * FROM customers");

      $result = $this->db->resultSet();

      return $result;
   }
}
 