<?php
//require libraries from the lib folder
   require_once 'lib/Core.php';
   require_once 'lib/Controller.php';
   require_once 'lib/Database.php';

   require_once 'config/config.php';

   $init = new Core();